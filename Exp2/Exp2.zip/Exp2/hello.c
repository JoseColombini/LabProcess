
void main() {
     printf("hello");
}
